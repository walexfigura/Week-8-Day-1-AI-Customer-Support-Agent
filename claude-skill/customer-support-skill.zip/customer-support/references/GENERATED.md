# Generated files

`knowledge-base/`, `workflows/`, and `sample-data/` were copied from the source repository by
`python run.py build-skill`. Edit the originals there, not these copies.

Everything in `sample-data/` is FICTIONAL demonstration data for Northstar Supply.
